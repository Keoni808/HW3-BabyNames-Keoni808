/**
  Created by KEONI MORTENSEN on 02/06/2019
 **/

import java.awt.*;
import java.util.*;
import java.io.*;

public class BabyNames {

    //Class constants
    private static final String MEANING_FILENAME = "meanings.txt";
    private static final String NAME_FILENAME = "names.txt";
    private static final int STARTING_YEAR = 1890;
    private static final int DECADE_WIDTH = 60;
    private static final int LEGEND_HEIGHT = 30;

    private static final DrawingPanel p = new DrawingPanel (780,560);

    public static void main(String[] args)
    throws FileNotFoundException{
        //Introduction to what the program does.
        System.out.println("This program allows you to search through the");
        System.out.println("data from the Social Security Administration");
        System.out.println("to see how popular a particular name has been");
        System.out.println("since " + STARTING_YEAR + ".");
        System.out.println();

        //Blank canvas. After info is taken from user, canvas will be filled.
        canvas(p);

        // Variables for name and gender
        String chosenName = nameChoice();
        String gender = genderChoice();

        //Scanning both files for name popularity and meaning
        Scanner popularity = new Scanner (new File (NAME_FILENAME));
        Scanner meaning = new Scanner (new File (MEANING_FILENAME));

        //retreiving information for name popularity and meaning
        namePopularity(popularity, chosenName, gender);
        nameMeaning(meaning, chosenName, gender);
    }

    // searches for meaning in name chosen
    private static String nameMeaning (Scanner input, String name, String gender) {

        // to match meanings.txt names
        String name2 = name.toUpperCase();
            while (input.hasNextLine()) {
                String text = input.nextLine();
                // first check to see if names match
                if (text.startsWith(name2)) {
                    Scanner secondCheck = new Scanner(text);
                    String lengthCheck = secondCheck.next();
                    // second check to see if lengths match
                    if(lengthCheck.length() == name.length()){
                        String genderVar = secondCheck.next();
                        // third check to see if genders match
                        if (genderVar.equalsIgnoreCase(gender)) {
                            printMeaning(text);
                            drawMeaning(p, text);
                            return text;
                        }
                    }
                }
            }
            return ("(no meaning found)");
    }

    // searches for meaning in name chosen
    private static void namePopularity (Scanner input, String name, String gender) {

        int count = 0;
        // to match names.txt names
        // the ammount of holes I had to jump through to capitalize the first letter was absurd.
        String name2 = name.toUpperCase();
        char name2FirstChar = name2.charAt(0);
        String name3 = name2.substring(1,name2.length());
        String name4 = name3.toLowerCase();
        String finalName = name2FirstChar + name4;

        while (input.hasNextLine()) {
            String text = input.nextLine();
            // first check to see if names match
            if (text.startsWith(finalName)) {
                Scanner secondCheck = new Scanner(text);
                String lengthCheck = secondCheck.next();
                // second check to see if lengths match
                if(lengthCheck.length() == name.length()){
                    String genderVar = secondCheck.next();
                    // third check to see if genders match
                    if (genderVar.equalsIgnoreCase(gender)) {
                        drawNamesChart(text);
                        count++;
                    }
                }
            }
        }
        if (count == 0) {
            System.out.println("\"" + name + "\" not found.");
        }
    }

    private static void printMeaning(String textLine) {
        Scanner text = new Scanner(textLine);
        System.out.print(text.next());
        while (text.hasNext()) {
            System.out.print(" " + text.next());
        }
        System.out.println();
    }

    //prompting user for a name
    private static String nameChoice() {
        String nameChosen;

        Scanner console = new Scanner(System.in);
        System.out.print("Name: ");
        nameChosen = console.next();

        return nameChosen;
    }

    //prompting user for a gender
    private static String genderChoice() {
        String genderChosen = "t";

        Scanner console = new Scanner(System.in);
        System.out.print("Gender (M or F): ");
        genderChosen = console.next();

        return genderChosen;
    }

    // setting up the blank Drawing Panel and legends.
    private static void canvas(DrawingPanel p) {
        //Setting up drawing panel with white background
        p.setBackground(Color.WHITE);

        //Creating top and bottom legends
        Graphics g = p.getGraphics();
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(0,0,780,LEGEND_HEIGHT);
        g.fillRect(0,560 - LEGEND_HEIGHT,780,LEGEND_HEIGHT);

        //Creating black lines for legends
        g.setColor(Color.BLACK);
        g.drawLine(0,LEGEND_HEIGHT,780,LEGEND_HEIGHT);
        g.drawLine(0,560,780,560);
        g.drawLine(0,560 - LEGEND_HEIGHT,780,560-LEGEND_HEIGHT);
    }

    private static void drawMeaning(DrawingPanel p, String message){
        Graphics g = p.getGraphics();
        g.drawString(message,0,16);
    }

    private static void drawNamesChart(String textLine){
        Graphics g = p.getGraphics();
        Scanner text = new Scanner(textLine);
        String chosenName = text.next();
        String chosenGender = text.next();
        System.out.print(chosenName + " ");
        System.out.print(chosenGender);

        int count = 0;
        int height = 0;
        int y = 0;

        while (text.hasNextInt()) {
            int rank = text.nextInt();
            System.out.print(" " + rank);
            if (rank == 0){
                y = 560 - LEGEND_HEIGHT;
                height = 0;
            } else {
                y = LEGEND_HEIGHT + (rank/2);
                height = (560 - LEGEND_HEIGHT) - y;
            }
            g.setColor(Color.GREEN);
            g.fillRect(DECADE_WIDTH * count, y, DECADE_WIDTH/2, height);
            g.setColor(Color.BLACK);
            g.drawString(""+(STARTING_YEAR + (count * 10)), DECADE_WIDTH * count, 552);
            g.drawString(""+rank, DECADE_WIDTH * count, y );
            count++;
        }
        System.out.println();
    }
}
